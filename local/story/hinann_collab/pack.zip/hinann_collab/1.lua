
en = {
["series.hinann"] = "Hinan",
["background.hinann"] = "World of Hinan",
["place.hinann.road1"] = "Road",
["place.hinann.road2"] = "Road 2",
["place.hinann.city"] = "The City",
["hinann.1"] = "Into the dream",
["hinann.2"] = "How can it be tackled?",
["hinann.3"] = "Beat them down?",
["character.nann"] = "Nann",
}

language.addMulti("en", "en", true)

ja = {
["series.hinann"] = "ひなん",
["background.hinann"] = "ひなんの世界",
["place.hinann.road1"] = "道",
["place.hinann.road2"] = "道2",
["place.hinann.city"] = "街",
["hinann.1"] = "夢の中へ",
["hinann.2"] = "困ったもんだ",
["hinann.3"] = "奴を倒せ?",
["character.nann"] = "ナン",

}

language.addMulti("jp", "ja", true)

storymanager.AddBackground("hinann", language.get("story.background.hinann"), "1.png")
storymanager.AddPlace("hinann", "hinann_road1", language.get("story.place.hinann.road1"), 0, -300)
storymanager.AddPlace("hinann", "hinann_road2", language.get("story.place.hinann.road2"), -100, -300)
storymanager.AddPlace("hinann", "hinann_city", language.get("story.place.hinann.city"), -200, -300)

storymanager.AddStory("hinann_road1", "hinann_story_1", "C-1", language.get("story.hinann.1"), "story/1.lua")
storymanager.AddStory("hinann_road2", "hinann_story_2", "C-2", language.get("story.hinann.2"), "story/2.lua", "hinann_story_1", 1, 0)
storymanager.AddStory("hinann_city", "hinann_story_3", "C-3", language.get("story.hinann.3"), "story/3.lua", "hinann_story_2", 2, 0)

storymanager.AddSeries("story_hinann", "#story.series.hinann", {"hinann_story_1", "hinann_story_2", "hinann_story_3"})