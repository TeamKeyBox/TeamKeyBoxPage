
en = {
["mes.hinan.2.1"] = "I want to see it!",
["mes.hinan.2.2"] = "Eh, uh...",
["mes.hinan.2.3"] = "Let's try to think how to meet him!",
["mes.hinan.2.4"] = "You shoudn't, cuz he is very wild.",
["mes.hinan.2.5"] = "Well, let's...play anything till I come up with something!",
["mes.hinan.2.6"] = "Hear me out.",
["mes.hinan.2.7"] = "Hurray! We could finally come in!",
["mes.hinan.2.8"] = "Wa-wait, HOW? What happened?",
["mes.hinan.2.9"] = "Take it easy. Look! Is that the creature you said?",
["mes.hinan.2.10"] = "Come on, KeyBoxer. We should go out, shouldn't we?",
["mes.hinan.2.11"] = "Heeey! Mr.Creature! Play with me!",
["mes.hinan.2.12"] = "You REALLY don't hear me out.",
}

language.addMulti("en", "en", true)

ja = {
["mes.hinan.2.1"] = "会ってみたい！",
["mes.hinan.2.2"] = "え、えぇ...",
["mes.hinan.2.3"] = "頑張って会う方法を考えてみる！",
["mes.hinan.2.4"] = "やめておいた方がいいよ。あの怪獣狂暴だし...",
["mes.hinan.2.5"] = "んーじゃ、思いつくまで適当に演奏する！",
["mes.hinan.2.6"] = "聞いてないし...",
["mes.hinan.2.7"] = "やったー！中に入れた！",
["mes.hinan.2.8"] = "え、え、なんでなんで...何が起きたの?",
["mes.hinan.2.9"] = "細かいことは置いておいて、あそこに見えるのがナンくんが言ってた怪獣?",
["mes.hinan.2.10"] = "ねえ～やっぱり出た方がいいんじゃない...?",
["mes.hinan.2.11"] = "怪獣さーん！あーそーぼ～！",
["mes.hinan.2.12"] = "また聞いてないし...",

}

language.addMulti("jp", "ja", true)

keybox.addCharacterSync("KeyBoxer", "KeyBoxer")
keybox.addCharacterSync("Nann", "#story.character.nann")
keybox.setCharacterSync(true)

music.setVolume(0)

keybox.fade(0.1, 0, 0, 0, 255)

keybox.setBackground(1)

keybox.run(function()

obj("KeyBoxer").active = true
obj("KeyBoxer").ox = -400
obj("Nann").active = true
obj("Nann").ox = 400

end)

keybox.fade(1, 0, 0, 0, 0)

keybox.message("#story.mes.hinan.2.1", "KeyBoxer")
keybox.setFace("Nann", 2, 2)
keybox.message("#story.mes.hinan.2.2", "#story.character.nann")
keybox.setFace("Nann", 2, 3)
keybox.message("#story.mes.hinan.2.3", "KeyBoxer")
keybox.setFace("Nann", 2, 2)
keybox.message("#story.mes.hinan.2.4", "#story.character.nann")
keybox.setFace("Nann", 2, 3)
keybox.message("#story.mes.hinan.2.5", "KeyBoxer")
keybox.setFace("Nann", 1, 2)
keybox.message("#story.mes.hinan.2.6", "#story.character.nann")
--
keybox.playKBM("meganekoSpaceMagic")

keybox.addCharacterSync("KeyBoxer", "KeyBoxer")
keybox.addCharacterSync("Nann", "#story.character.nann")
keybox.setCharacterSync(true)

keybox.run(function()

obj("KeyBoxer").active = true
obj("KeyBoxer").ox = -300
obj("Nann").active = true
obj("Nann").ox = 300

end)
--
keybox.setFace("Nann", 0, 3)
keybox.message("#story.mes.hinan.2.7", "KeyBoxer")
keybox.setFace("Nann", 0, 2)
keybox.message("#story.mes.hinan.2.8", "#story.character.nann")
keybox.setFace("Nann", 0, 3)
keybox.message("#story.mes.hinan.2.9", "KeyBoxer")
--(レジーデンがいる)
--(咆哮)
keybox.sprite.load("pic_hinann_2", "2.png")

local pic_1_1 = nil

keybox.sprite.create("pic_hinann_2", function(ob)

ob.zoom = 5
pic_1_1 = ob

end)

keybox.wait(1.5)

local pic_1_2 = nil

keybox.sprite.create("pic_hinann_2", function(ob)

pic_1_1:remove()

ob.zoom = 6
pic_1_2 = ob

--ob:Animate("shake", 1)

end)

keybox.animate("pic_hinann_2", "shake", 1.0)

keybox.sound.play("3_uptension")

keybox.wait(1)

keybox.setFace("Nann", 2, 2)
keybox.message("#story.mes.hinan.2.10", "#story.character.nann")
keybox.setFace("Nann", 2, 3)
keybox.message("#story.mes.hinan.2.11", "KeyBoxer")
keybox.setFace("Nann", 1, 2)
keybox.message("#story.mes.hinan.2.12", "#story.character.nann")

keybox.showNewSongModal("meganekoSpaceMagic", {0, 3})

keybox.endstory(1)