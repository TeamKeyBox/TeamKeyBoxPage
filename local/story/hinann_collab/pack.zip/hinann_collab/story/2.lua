
en = {
["mes.1.1.1"] = "I want to be famous!",
["mes.1.1.2"] = "...It's easy to think so.",
["mes.1.1.3"] = "It's boring...",
["mes.1.1.4"] = "Should I \"play\" something today?",
["mes.1.1.5"] = "The music that I use for alarm...sounds good.",
["mes.1.1.6"] = "Well, I decided which to play!",
["mes.1.1.7"] = "I think I played well today.",
["mes.1.1.8"] = "But it's not good to play the same music.",
["mes.1.1.9"] = "...Let's find new musics!",
["mes.1.1.10"] = "Perhaps, I could be famous.",

["mes.1.1.11"] = "\"This\" is Dubpage, a country in another world.",
["mes.1.1.12"] = "It's developed, and is loud, but looks fun...maybe?",
["mes.1.1.13"] = "The reason I said \"maybe\" is because there is a matter.",
["mes.1.1.14"] = "However, that will be never mentioned in this story.",
["mes.1.1.15"] = "I hope someone will tell it.",
["mes.1.1.16"] = "Anyway, there was a creature.",
["mes.1.1.17"] = "Its body is constructed with cubes, floating hands, and hovering head cube.",
["mes.1.1.18"] = "Regardless of its unreality, no one was attracted to him...",
["mes.1.1.19"] = "...yet, but",
["mes.1.1.20"] = "he thinks that will become real someday.",
["mes.1.1.21"] = "Let's see his activity.",
["mes.1.1.22"] = "You have to think what \"Key\" can open the \"Box\",",
["mes.1.1.23"] = "in this story.",
}

language.addMulti("en", "en", true)

ja = {
["mes.hinan.2.1"] = "会ってみたい！",
["mes.hinan.2.2"] = "え、えぇ...",
["mes.hinan.2.3"] = "頑張って会う方法を考えてみる！",
["mes.hinan.2.4"] = "やめておいた方がいいよ。あの怪獣狂暴だし...",
["mes.hinan.2.5"] = "んーじゃ、思いつくまで適当に演奏する！",
["mes.hinan.2.6"] = "聞いてないし...",
["mes.hinan.2.7"] = "やったー！中に入れた！",
["mes.hinan.2.8"] = "え、え、なんでなんで...何が起きたの?",
["mes.hinan.2.9"] = "細かいことは置いておいて、あそこに見えるのがナンくんが言ってた怪獣?",
["mes.hinan.2.10"] = "ねえ～やっぱり出た方がいいんじゃない...?",
["mes.hinan.2.11"] = "怪獣さーん！あーそーぼ～！",
["mes.hinan.2.12"] = "また聞いてないし...",

}

language.addMulti("jp", "ja", true)

keybox.addCharacterSync("KeyBoxer", "KeyBoxer")
keybox.addCharacterSync("Nann", "#story.character.nann")
keybox.setCharacterSync(true)

music.setVolume(0)

keybox.fade(0.1, 0, 0, 0, 255)

keybox.run(function()

obj("KeyBoxer").active = true
obj("KeyBoxer").ox = -300
obj("Nann").active = true
obj("Nann").ox = 300

end)

keybox.fade(1, 0, 0, 0, 0)

keybox.message("#story.mes.hinan.2.1", "KeyBoxer")
keybox.setFace("Nann", 2, 2)
keybox.message("#story.mes.hinan.2.2", "#story.character.nann")
keybox.setFace("Nann", 2, 3)
keybox.message("#story.mes.hinan.2.3", "KeyBoxer")
keybox.setFace("Nann", 2, 2)
keybox.message("#story.mes.hinan.2.4", "#story.character.nann")
keybox.setFace("Nann", 2, 3)
keybox.message("#story.mes.hinan.2.5", "KeyBoxer")
keybox.setFace("Nann", 1, 2)
keybox.message("#story.mes.hinan.2.6", "#story.character.nann")
--
keybox.playKBM("meganekoSpaceMagic")

keybox.addCharacterSync("KeyBoxer", "KeyBoxer")
keybox.addCharacterSync("Nann", "#story.character.nann")
keybox.setCharacterSync(true)

keybox.run(function()

obj("KeyBoxer").active = true
obj("KeyBoxer").ox = -300
obj("Nann").active = true
obj("Nann").ox = 300

end)
--
keybox.setFace("Nann", 0, 3)
keybox.message("#story.mes.hinan.2.7", "KeyBoxer")
keybox.setFace("Nann", 0, 2)
keybox.message("#story.mes.hinan.2.8", "#story.character.nann")
keybox.setFace("Nann", 0, 3)
keybox.message("#story.mes.hinan.2.9", "KeyBoxer")
--(レジーデンがいる)
--(咆哮)

keybox.setFace("Nann", 2, 2)
keybox.message("#story.mes.hinan.2.10", "#story.character.nann")
keybox.setFace("Nann", 2, 3)
keybox.message("#story.mes.hinan.2.11", "KeyBoxer")
keybox.setFace("Nann", 1, 2)
keybox.message("#story.mes.hinan.2.12", "#story.character.nann")


keybox.endstory(1)