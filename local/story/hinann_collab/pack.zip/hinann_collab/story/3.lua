
en = {
["mes.hinan.3.1"] = "Oops!",
["mes.hinan.3.2"] = "Oh, no!",
["mes.hinan.3.3"] = "The wall has a hole!",
["mes.hinan.3.4"] = "Oh, really?",
["mes.hinan.3.5"] = "How should I do? If this continues, the creature will be eventually released!",
["mes.hinan.3.6"] = "Then, let's beat him down!",
["mes.hinan.3.7"] = "Beat...what? How?",
["mes.hinan.3.8"] = "Let me see...maybe, play something again?",
["mes.hinan.3.9"] = "Huh?",
["mes.hinan.3.10"] = "I did it!",
["mes.hinan.3.11"] = "I can't understand...",
["mes.hinan.3.12"] = "...but, uh, yeah.",
["mes.hinan.3.13"] = "This is the best ending, if I don't have to tackle this matter anymore.",
["mes.hinan.3.14"] = "Hmm?",
["mes.hinan.3.15"] = "He seems to have become a box.",
["mes.hinan.3.16"] = "Eh?",
["mes.hinan.3.17"] = "It became more convenient to carry!",
["mes.hinan.3.18"] = "Nope, IT HAS BEEN.",
["mes.hinan.3.19"] = "Anyway, thanks for everything, Nann.",
["mes.hinan.3.20"] = "Well, I did nothing.",
["mes.hinan.3.21"] = "But I want to ask, how are you going to treat this?",
["mes.hinan.3.22"] = "I will take him!",
["mes.hinan.3.23"] = "You take him? Uh...",
["mes.hinan.3.24"] = "It's time to return.",
["mes.hinan.3.25"] = "Goodbye!",
["mes.hinan.3.26"] = "...well, see you later!",
["mes.hinan.3.27"] = "Ah, it was very exciting,",
["mes.hinan.3.28"] = "<type speed=\"120\">as if I were in a dre</>a<type forceskip=\"true\">m.</>",
["mes.hinan.3.29"] = "Huh?",
["mes.hinan.3.30"] = "That was actually...a dream.",
["mes.hinan.3.31"] = "But even so, it was fun!",
["mes.hinan.3.32"] = "By the way, what should I eat this noon?",

["mes.hinan.gameover.1"] = "The game is over, but we have no gameover-screen, so you'll be taken back to the menu.",
}

language.addMulti("en", "en", true)

ja = {
["mes.hinan.3.1"] = "わっ！",
["mes.hinan.3.2"] = "あ！まずい！",
["mes.hinan.3.3"] = "壁に穴が開いちゃったよ！",
["mes.hinan.3.4"] = "え? ホント?",
["mes.hinan.3.5"] = "どうしよう...このままだと、怪獣が解放されちゃう！",
["mes.hinan.3.6"] = "じゃあ、怪獣を倒そう！",
["mes.hinan.3.7"] = "倒すって...どうやって！",
["mes.hinan.3.8"] = "うーん...やっぱり思いつくまで適当に演奏する！",
["mes.hinan.3.9"] = "えええ～！",
["mes.hinan.3.10"] = "倒せた！",
["mes.hinan.3.11"] = "本当になんなの...この生物...",
["mes.hinan.3.12"] = "...まあでも、いっか。",
["mes.hinan.3.13"] = "これでよかったんだよね...これでもう走り回らなくて済むなら...",
["mes.hinan.3.14"] = "あれ?",
["mes.hinan.3.15"] = "なんか、箱になっちゃったけど...",
["mes.hinan.3.16"] = "え?",
["mes.hinan.3.17"] = "持ち運びしやすくなった！",
["mes.hinan.3.18"] = "いやいやいや...元から持ち運びしやすかったから...",
["mes.hinan.3.19"] = "ありがとうね、ナン君。",
["mes.hinan.3.20"] = "まあ、僕何もしてないけどね。",
["mes.hinan.3.21"] = "でも、その怪獣どうするの?",
["mes.hinan.3.22"] = "この怪獣は持って帰る！",
["mes.hinan.3.23"] = "ええ...",
["mes.hinan.3.24"] = "それじゃ、ボクはもう帰るから、",
["mes.hinan.3.25"] = "さよーなら！",
["mes.hinan.3.26"] = "...うん、さようなら！",
["mes.hinan.3.27"] = "いやー、楽しかったね～...",
["mes.hinan.3.28"] = "<type speed=\"120\">あっという間すぎて、まるで</>夢<type forceskip=\"true\">みたいだったね</>",
["mes.hinan.3.29"] = "あれ?",
["mes.hinan.3.30"] = "...夢だったんだ。",
["mes.hinan.3.31"] = "でも、楽しかったし、いっか！",
["mes.hinan.3.32"] = "昼ごはん何にしようかな...",

["mes.hinan.gameover.1"] = "ゲームオーバーになりましたが、専用の画面を用意していないため、とりあえずメニュー画面に戻します。",

}

language.addMulti("jp", "ja", true)

keybox.addCharacterSync("KeyBoxer", "KeyBoxer")
keybox.addCharacterSync("Nann", "#story.character.nann")
keybox.setCharacterSync(true)

music.setVolume(0)

keybox.fade(0.1, 0, 0, 0, 255)

keybox.run(function()

obj("KeyBoxer").active = true
obj("KeyBoxer").ox = -300
obj("Nann").active = true
obj("Nann").ox = 300

end)

keybox.sprite.load("pic_hinann_2", "2.png")

local pic_1_1 = nil

keybox.sprite.create("pic_hinann_2", function(ob)

ob.zoom = 5
pic_1_1 = ob

end)

keybox.setFace("Nann", 0, 3)

keybox.fade(1, 0, 0, 0, 0)

--(レジーデンが炎を噴射する攻撃をしかけてくる)

keybox.message("#story.mes.hinan.3.1", "KeyBoxer")
keybox.setFace("Nann", 0, 2)

keybox.animate("pic_hinann_2", "shake", 1.0)

keybox.message("#story.mes.hinan.3.2", "#story.character.nann")

keybox.run(function()

pic_1_1:remove()

end)

keybox.message("#story.mes.hinan.3.3", "#story.character.nann")
keybox.setFace("Nann", 0, 3)
keybox.message("#story.mes.hinan.3.4", "KeyBoxer")
keybox.setFace("Nann", 4, 2)
keybox.message("#story.mes.hinan.3.5", "#story.character.nann")
--(入力受付開始)
local songlist = {"ssmHinan", "ssmHinan"}
keybox.typeText("limitbreak", function ()
table.insert(songlist, "ssmCorruptedMemory")
end, true)
keybox.setFace("Nann", 4, 3)
keybox.message("#story.mes.hinan.3.6", "KeyBoxer")
keybox.setFace("Nann", 2, 2)
keybox.message("#story.mes.hinan.3.7", "#story.character.nann")
keybox.setFace("Nann", 2, 3)
keybox.message("#story.mes.hinan.3.8", "KeyBoxer")
keybox.setFace("Nann", 4, 2)
keybox.message("#story.mes.hinan.3.9", "#story.character.nann")
keybox.typeText("")
--(ここまでの間に"limitbreak"と入力すると多くの楽曲を選択可能)
--
keybox.showBattleTutorial()
keybox.run(function()
	keybox.startInsert()
	
	keybox.playInBattleMode("keyboxer", {{
		HP = 6000,
		Armor = 0,
		Defence = 100,
		Regen = 100,
		Position = 30,
		attacks = {{Strength = 200, CriticalPercentage = 1, Velocity = 50, Frequency = 200}},
		character = "residen"
	}}, songlist, 3)
	
	keybox.endInsert()
end)

keybox.fade(0.1, 0, 0, 0, 255)

keybox.addCharacterSync("KeyBoxer", "KeyBoxer")
keybox.addCharacterSync("Nann", "#story.character.nann")
keybox.setCharacterSync(true)

keybox.setBackground(1)

keybox.run(function()

obj("KeyBoxer").active = true
obj("KeyBoxer").ox = -300
obj("Nann").active = true
obj("Nann").ox = 300

local result = keybox.getLastResult()
if (result.battlestate <= 0) then
	keybox.startInsert()
	
	keybox.message("#story.mes.hinan.gameover.1", "_")
	
	keybox.endstory(-1)
	
	keybox.endInsert()
else

local alt = (result.songSkill == 13)

keybox.startInsert()

keybox.setFace("Nann", 2, 3)

keybox.fade(1, 0, 0, 0, 0)
--("limitbreak"状態で物理攻撃の楽曲を選び勝利すると、"alt"フラグ付与)
--
keybox.message("#story.mes.hinan.3.10", "KeyBoxer")
keybox.setFace("Nann", 2, 2)
keybox.message("#story.mes.hinan.3.11", "#story.character.nann")
keybox.setFace("Nann", 1, 1)
keybox.message("#story.mes.hinan.3.12", "#story.character.nann")
keybox.setFace("Nann", 0, 1)
keybox.message("#story.mes.hinan.3.13", "#story.character.nann")
keybox.setFace("Nann", 0, 0)
if (not alt) then
--(分岐開始、以下のメッセージは"alt"フラグ時には省略される)
keybox.message("#story.mes.hinan.3.14", "KeyBoxer")
--(アルキマがレジーデンを封印するがKeyBoxerはそれに気づかない)
keybox.message("#story.mes.hinan.3.15", "KeyBoxer")
keybox.setFace("Nann", 0, 2)
keybox.message("#story.mes.hinan.3.16", "#story.character.nann")
keybox.setFace("Nann", 0, 3)
keybox.message("#story.mes.hinan.3.17", "KeyBoxer")
keybox.setFace("Nann", 1, 1)
keybox.message("#story.mes.hinan.3.18", "#story.character.nann")
--(分岐終了)
end

keybox.fade(0.5, 0, 0, 0, 255)

keybox.setFace("Nann", 0, 0)

keybox.fade(0.5, 0, 0, 0, 0)

--
keybox.message("#story.mes.hinan.3.19", "KeyBoxer")
keybox.setFace("Nann", 0, 1)
keybox.message("#story.mes.hinan.3.20", "#story.character.nann")
if (not alt) then
--(分岐開始、条件は上と同じ)
keybox.setFace("Nann", 0, 2)
keybox.message("#story.mes.hinan.3.21", "#story.character.nann")
keybox.setFace("Nann", 0, 3)
keybox.message("#story.mes.hinan.3.22", "KeyBoxer")
keybox.setFace("Nann", 2, 2)
keybox.message("#story.mes.hinan.3.23", "#story.character.nann")
keybox.setFace("Nann", 0, 3)
--(分岐終了)
else
keybox.setFace("Nann", 0, 0)
end
keybox.message("#story.mes.hinan.3.24", "KeyBoxer")
keybox.setFace("Nann", 0, 0)
keybox.message("#story.mes.hinan.3.25", "KeyBoxer")
keybox.setFace("Nann", 3, 1)
keybox.message("#story.mes.hinan.3.26", "#story.character.nann")

keybox.fade(0.5, 0, 0, 0, 255)

keybox.run(function()

obj("Nann").active = false
obj("KeyBoxer").ox = 0

end)

keybox.fade(0.5, 0, 0, 0, 0)
--
keybox.message("#story.mes.hinan.3.27", "KeyBoxer")
keybox.message("#story.mes.hinan.3.28", "KeyBoxer")
--(急に夢から覚める)
keybox.setBackground(0)

keybox.sprite.load("pic_hinann_3", "3.png")

local pic_1_3 = nil

keybox.sprite.create("pic_hinann_3", function(ob)

ob.zoom = 5
pic_1_3 = ob

end)

music.setVolume(0)
keybox.message("#story.mes.hinan.3.29", "KeyBoxer")
keybox.message("#story.mes.hinan.3.30", "KeyBoxer")

if (alt) then
	keybox.sprite.load("pic_hinann_4", "4_background_2.png")
else
	keybox.sprite.load("pic_hinann_4", "4_background_1.png")
end
keybox.sprite.load("pic_hinann_4_keyboxer", "4_keyboxer.png")

local pic_1_4 = nil
local pic_1_4_keyboxer = nil

keybox.sprite.create("pic_hinann_4", function(ob)

pic_1_3:remove()

ob.zoom = 5
pic_1_4 = ob

end)

keybox.sprite.create("pic_hinann_4_keyboxer", function(ob)

ob.zoom = 5
pic_1_4_keyboxer = ob

end)

keybox.message("#story.mes.hinan.3.31", "KeyBoxer")

keybox.run(function()

pic_1_4_keyboxer:TranslateX(960, 1.5)

end)

keybox.message("#story.mes.hinan.3.32", "KeyBoxer")
--
--(ある)

if (alt) then
	save.setInt("hinann_alt", 1)
	keybox.showNewSongModal("ssmCorruptedMemory", {3})
end

keybox.showNewSongModal("ssmHinan", {1, 2, 3})

keybox.endstory(1)

keybox.endInsert()

end

end)

