
en = {
["mes.1.1.1"] = "I want to be famous!",
["mes.1.1.2"] = "...It's easy to think so.",
["mes.1.1.3"] = "It's boring...",
["mes.1.1.4"] = "Should I \"play\" something today?",
["mes.1.1.5"] = "The music that I use for alarm...sounds good.",
["mes.1.1.6"] = "Well, I decided which to play!",
["mes.1.1.7"] = "I think I played well today.",
["mes.1.1.8"] = "But it's not good to play the same music.",
["mes.1.1.9"] = "...Let's find new musics!",
["mes.1.1.10"] = "Perhaps, I could be famous.",

["mes.1.1.11"] = "\"This\" is Dubpage, a country in another world.",
["mes.1.1.12"] = "It's developed, and is loud, but looks fun...maybe?",
["mes.1.1.13"] = "The reason I said \"maybe\" is because there is a matter.",
["mes.1.1.14"] = "However, that will be never mentioned in this story.",
["mes.1.1.15"] = "I hope someone will tell it.",
["mes.1.1.16"] = "Anyway, there was a creature.",
["mes.1.1.17"] = "Its body is constructed with cubes, floating hands, and hovering head cube.",
["mes.1.1.18"] = "Regardless of its unreality, no one was attracted to him...",
["mes.1.1.19"] = "...yet, but",
["mes.1.1.20"] = "he thinks that will become real someday.",
["mes.1.1.21"] = "Let's see his activity.",
["mes.1.1.22"] = "You have to think what \"Key\" can open the \"Box\",",
["mes.1.1.23"] = "in this story.",
}

language.addMulti("en", "en", true)

ja = {
["mes.hinan.3.1"] = "わっ！",
["mes.hinan.3.2"] = "あ！まずい！",
["mes.hinan.3.3"] = "壁に穴が開いちゃったよ！",
["mes.hinan.3.4"] = "え? ホント?",
["mes.hinan.3.5"] = "どうしよう...このままだと、怪獣が解放されちゃう！",
["mes.hinan.3.6"] = "じゃあ、怪獣を倒そう！",
["mes.hinan.3.7"] = "倒すって...どうやって！",
["mes.hinan.3.8"] = "うーん...やっぱり思いつくまで適当に演奏する！",
["mes.hinan.3.9"] = "えええ～！",
["mes.hinan.3.10"] = "倒せた！",
["mes.hinan.3.11"] = "本当になんなの...この生物...",
["mes.hinan.3.12"] = "...まあでも、いっか。",
["mes.hinan.3.13"] = "これでよかったんだよね...これでもう走り回らなくて済むなら...",
["mes.hinan.3.14"] = "あれ?",
["mes.hinan.3.15"] = "なんか、箱になっちゃったけど...",
["mes.hinan.3.16"] = "え?",
["mes.hinan.3.17"] = "持ち運びしやすくなった！",
["mes.hinan.3.18"] = "いやいやいや...元から持ち運びしやすかったから...",
["mes.hinan.3.19"] = "ありがとうね、ナン君。",
["mes.hinan.3.20"] = "まあ、僕何もしてないけどね。",
["mes.hinan.3.21"] = "でも、その怪獣どうするの?",
["mes.hinan.3.22"] = "この怪獣は持って帰る！",
["mes.hinan.3.23"] = "ええ...",
["mes.hinan.3.24"] = "それじゃ、ボクはもう帰るから、",
["mes.hinan.3.25"] = "さよーなら！",
["mes.hinan.3.26"] = "...うん、さようなら！",
["mes.hinan.3.27"] = "いやー、楽しかったね～...",
["mes.hinan.3.28"] = "<type speed=\"120\">あっという間すぎて、まるで</><type forceskip=\"true\">夢</>",
["mes.hinan.3.29"] = "あれ?",
["mes.hinan.3.30"] = "...夢だったんだ。",
["mes.hinan.3.31"] = "でも、楽しかったし、いっか！",
["mes.hinan.3.32"] = "昼ごはん何にしようかな...",

}

language.addMulti("jp", "ja", true)

keybox.addCharacterSync("KeyBoxer", "KeyBoxer")
keybox.addCharacterSync("Nann", "#story.character.nann")
keybox.setCharacterSync(true)

music.setVolume(0)

keybox.fade(0.1, 0, 0, 0, 255)

keybox.run(function()

obj("KeyBoxer").active = true
obj("KeyBoxer").ox = -300
obj("Nann").active = true
obj("Nann").ox = 300

end)

keybox.setFace("Nann", 0, 3)

keybox.fade(1, 0, 0, 0, 0)

--(レジーデンが炎を噴射する攻撃をしかけてくる)
keybox.message("#story.mes.hinan.3.1", "KeyBoxer")
keybox.setFace("Nann", 0, 2)
keybox.message("#story.mes.hinan.3.2", "#story.character.nann")
keybox.message("#story.mes.hinan.3.3", "#story.character.nann")
keybox.setFace("Nann", 0, 3)
keybox.message("#story.mes.hinan.3.4", "KeyBoxer")
keybox.setFace("Nann", 4, 2)
keybox.message("#story.mes.hinan.3.5", "#story.character.nann")
--(入力受付開始)
local songlist = {"ssmHinan", "ssmIdola"}
keybox.typeText("limitbreak", function ()
table.insert(songlist, "ssmCorruptedMemory")
end, true)
keybox.setFace("Nann", 4, 3)
keybox.message("#story.mes.hinan.3.6", "KeyBoxer")
keybox.setFace("Nann", 2, 2)
keybox.message("#story.mes.hinan.3.7", "#story.character.nann")
keybox.setFace("Nann", 2, 3)
keybox.message("#story.mes.hinan.3.8", "KeyBoxer")
keybox.setFace("Nann", 4, 2)
keybox.message("#story.mes.hinan.3.9", "#story.character.nann")
keybox.typeText("")
--(ここまでの間に"limitbreak"と入力すると多くの楽曲を選択可能)
--
keybox.showBattleTutorial()
keybox.run(function()
	keybox.startInsert()
	
	keybox.playInBattleMode("keyboxer", {{
		HP = 6000,
		Armor = 0,
		Defence = 100,
		Regen = 100,
		Position = 30,
		attacks = {{Strength = 200, CriticalPercentage = 1, Velocity = 50, Frequency = 200}},
		character = "residen"
	}}, songlist, 3)
	
	keybox.endInsert()
end)

keybox.addCharacterSync("KeyBoxer", "KeyBoxer")
keybox.addCharacterSync("Nann", "#story.character.nann")
keybox.setCharacterSync(true)

keybox.run(function()

obj("KeyBoxer").active = true
obj("KeyBoxer").ox = -300
obj("Nann").active = true
obj("Nann").ox = 300

end)
keybox.setFace("Nann", 2, 3)
--("limitbreak"状態で物理攻撃の楽曲を選び勝利すると、"alt"フラグ付与)
--
keybox.message("#story.mes.hinan.3.10", "KeyBoxer")
keybox.setFace("Nann", 2, 2)
keybox.message("#story.mes.hinan.3.11", "#story.character.nann")
keybox.setFace("Nann", 1, 1)
keybox.message("#story.mes.hinan.3.12", "#story.character.nann")
keybox.setFace("Nann", 0, 1)
keybox.message("#story.mes.hinan.3.13", "#story.character.nann")
keybox.setFace("Nann", 0, 0)
--(分岐開始、以下のメッセージは"alt"フラグ時には省略される)
keybox.message("#story.mes.hinan.3.14", "KeyBoxer")
--(アルキマがレジーデンを封印するがKeyBoxerはそれに気づかない)
keybox.message("#story.mes.hinan.3.15", "KeyBoxer")
keybox.setFace("Nann", 0, 2)
keybox.message("#story.mes.hinan.3.16", "#story.character.nann")
keybox.setFace("Nann", 0, 3)
keybox.message("#story.mes.hinan.3.17", "KeyBoxer")
keybox.setFace("Nann", 1, 1)
keybox.message("#story.mes.hinan.3.18", "#story.character.nann")
--(分岐終了)

keybox.fade(0.5, 0, 0, 0, 255)

keybox.setFace("Nann", 0, 0)

keybox.fade(0.5, 0, 0, 0, 0)

--
keybox.message("#story.mes.hinan.3.19", "KeyBoxer")
keybox.setFace("Nann", 0, 1)
keybox.message("#story.mes.hinan.3.20", "#story.character.nann")
--(分岐開始、条件は上と同じ)
keybox.setFace("Nann", 0, 2)
keybox.message("#story.mes.hinan.3.21", "#story.character.nann")
keybox.setFace("Nann", 0, 3)
keybox.message("#story.mes.hinan.3.22", "KeyBoxer")
keybox.setFace("Nann", 2, 2)
keybox.message("#story.mes.hinan.3.23", "#story.character.nann")
--(分岐終了)
keybox.setFace("Nann", 0, 3)
keybox.message("#story.mes.hinan.3.24", "KeyBoxer")
keybox.setFace("Nann", 0, 0)
keybox.message("#story.mes.hinan.3.25", "KeyBoxer")
keybox.setFace("Nann", 3, 1)
keybox.message("#story.mes.hinan.3.26", "#story.character.nann")

keybox.fade(0.5, 0, 0, 0, 255)

keybox.run(function()

obj("Nann").active = false
obj("KeyBoxer").ox = 0

end)

keybox.fade(0.5, 0, 0, 0, 0)
--
keybox.message("#story.mes.hinan.3.27", "KeyBoxer")
keybox.message("#story.mes.hinan.3.28", "KeyBoxer")
--(急に夢から覚める)
keybox.message("#story.mes.hinan.3.29", "KeyBoxer")
keybox.message("#story.mes.hinan.3.30", "KeyBoxer")
keybox.message("#story.mes.hinan.3.31", "KeyBoxer")
keybox.message("#story.mes.hinan.3.32", "KeyBoxer")
--
--(ある)


keybox.endstory(1)