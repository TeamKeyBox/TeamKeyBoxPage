
en = {
["mes.1.1.1"] = "I want to be famous!",
["mes.1.1.2"] = "...It's easy to think so.",
["mes.1.1.3"] = "It's boring...",
["mes.1.1.4"] = "Should I \"play\" something today?",
["mes.1.1.5"] = "The music that I use for alarm...sounds good.",
["mes.1.1.6"] = "Well, I decided which to play!",
["mes.1.1.7"] = "I think I played well today.",
["mes.1.1.8"] = "But it's not good to play the same music.",
["mes.1.1.9"] = "...Let's find new musics!",
["mes.1.1.10"] = "Perhaps, I could be famous.",

["mes.1.1.11"] = "\"This\" is Dubpage, a country in another world.",
["mes.1.1.12"] = "It's developed, and is loud, but looks fun...maybe?",
["mes.1.1.13"] = "The reason I said \"maybe\" is because there is a matter.",
["mes.1.1.14"] = "However, that will be never mentioned in this story.",
["mes.1.1.15"] = "I hope someone will tell it.",
["mes.1.1.16"] = "Anyway, there was a creature.",
["mes.1.1.17"] = "Its body is constructed with cubes, floating hands, and hovering head cube.",
["mes.1.1.18"] = "Regardless of its unreality, no one was attracted to him...",
["mes.1.1.19"] = "...yet, but",
["mes.1.1.20"] = "he thinks that will become real someday.",
["mes.1.1.21"] = "Let's see his activity.",
["mes.1.1.22"] = "You have to think what \"Key\" can open the \"Box\",",
["mes.1.1.23"] = "in this story.",
}

language.addMulti("en", "en", true)

ja = {
["mes.hinan.1.1"] = "これは、ボクがまだ\"みんな\"と出会う前のお話。",
["mes.hinan.1.2"] = "ある日、ボクはいつも通りうたたねをしてたんだ。",
["mes.hinan.1.3"] = "ぐー...",
["mes.hinan.1.4"] = "あれ? ここはどこ?",
["mes.hinan.1.5"] = "ボクが見たことない場所みたいだけど...",
["mes.hinan.1.6"] = "んー、ま！どこでもいいから今日も演奏しよう！",
["mes.hinan.1.7"] = "せっかくだからこの曲にしようかな～...",
["mes.hinan.1.8"] = "完璧！やっぱり演奏はこうでなくちゃ！",
["mes.hinan.1.9"] = "いいねー！やっぱり演奏はこうでなくちゃ！",
["mes.hinan.1.10"] = "いい感じ！もっと<span color=\"0,255,255,255\">正確に</>演奏できるようになりたいな～！",
["mes.hinan.1.11"] = "いい感じ！<span color=\"255,255,0,255\">ミスをなくせば</>もっと良くなる気がする！",
["mes.hinan.1.12"] = "うん！もっと練習して<span color=\"255,255,0,255\">ミスを減らしたい</>ねー！",
["mes.hinan.1.13"] = "うーん...今日は<span color=\"255,0,0,255\">あんまり調子が良くない</>みたい。",
["mes.hinan.1.14"] = "はぁ...ボク<span color=\"255,0,0,255\">疲れちゃった</>よ。",
["mes.hinan.1.15"] = "...あれ?",
["mes.hinan.1.16"] = "この箱...はなんだろう?",
["mes.hinan.1.17"] = "なんか模様があるけど...よくわからないや。",
["mes.hinan.1.18"] = "あー！あったあった！",
["mes.hinan.1.19"] = "ん?",
["mes.hinan.1.20"] = "いやー...参ったよぉ...みんなこんなところに投げるんだから...",
["mes.hinan.1.21"] = "君は誰?",
["mes.hinan.1.22"] = "あれ? 見たことない生物だ！",
["mes.hinan.1.23"] = "ボクはKeyBoxer、他のところで寝てたはずなんだけど...",
["mes.hinan.1.24"] = "気づいたらこんなところに飛ばされてたんだ！",
["mes.hinan.1.25"] = "へぇ～、よろしく！KeyBoxer君。",
["mes.hinan.1.26"] = "それで、君の名前は?",
["mes.hinan.1.27"] = "僕はナン・ラフト。このあたりで自主的に街を守る活動をしてるんだ。",
["mes.hinan.1.28"] = "すごい！",
["mes.hinan.1.29"] = "ありがとうね。",
["mes.hinan.1.30"] = "そういえば、KeyBoxer君の手に持ってるその箱、渡してくれる?",
["mes.hinan.1.31"] = "うん。いいけど、何かあるの?",
["mes.hinan.1.32"] = "この箱にはね、巨大な怪獣が眠ってるんだ。",
["mes.hinan.1.33"] = "へえ～そうなんだ！",
["mes.hinan.1.34"] = "...驚かないの?",
["mes.hinan.1.35"] = "だって、楽しそうじゃん。",
["mes.hinan.1.36"] = "巨大な怪獣がいる町って、なんかわちゃわちゃしてて楽しそう！",
["mes.hinan.1.37"] = "そう...ま、いいけどね。",

}

language.addMulti("jp", "ja", true)

music.setVolume(0)

keybox.fade(0.1, 0, 0, 0, 255)

--(スキップ不可)
keybox.setSkippable(false)
keybox.message("#story.mes.hinan.1.1", "KeyBoxer")
keybox.message("#story.mes.hinan.1.2", "KeyBoxer")
keybox.setSkippable(true)

keybox.run(function()

obj("KeyBoxer").active = true

end)

keybox.setFace("KeyBoxer", 1, 0)

keybox.wait(1)

keybox.fade(1, 0, 0, 0, 0)

--
keybox.message("#story.mes.hinan.1.3", "KeyBoxer")
keybox.fade(2, 255, 255, 255, 255)
--(夢の世界に入る)
keybox.setBackground(1)
keybox.fade(1, 0, 0, 0, 0)
keybox.wait(1)
keybox.setFace("KeyBoxer", 0, 0)
keybox.bounce("KeyBoxer")
keybox.wait(1)

keybox.message("#story.mes.hinan.1.4", "KeyBoxer")
keybox.message("#story.mes.hinan.1.5", "KeyBoxer")
keybox.message("#story.mes.hinan.1.6", "KeyBoxer")
keybox.message("#story.mes.hinan.1.7", "KeyBoxer")
--
keybox.playKBM("lethalixJustadaydream")
keybox.setBackground(1)
keybox.run(function()

obj("KeyBoxer").active = true

local res = keybox.getLastResult()

keybox.startInsert()
if (res.scorePercentage >= 1.17) then
	--(理論値)
	keybox.message("#story.mes.hinan.1.8", "KeyBoxer")
elseif (res.clearstate == 5) then
	--(BM)
	keybox.message("#story.mes.hinan.1.9", "KeyBoxer")
elseif (res.clearstate == 4) then
	--(フルコン)
	keybox.message("#story.mes.hinan.1.10", "KeyBoxer")
elseif (res.clearstate == 3) then
	--(MAXクリア)
	keybox.message("#story.mes.hinan.1.11", "KeyBoxer")
elseif (res.clearstate == 2) then
	--(クリア)
	keybox.message("#story.mes.hinan.1.12", "KeyBoxer")
elseif (res.clearstate == 1) then
	--(クリア失敗)
	keybox.message("#story.mes.hinan.1.13", "KeyBoxer")
else
	--(Lost)
	keybox.message("#story.mes.hinan.1.14", "KeyBoxer")
end
keybox.endInsert()

end)

keybox.message("#story.mes.hinan.1.15", "KeyBoxer")
keybox.message("#story.mes.hinan.1.16", "KeyBoxer")
keybox.message("#story.mes.hinan.1.17", "KeyBoxer")
keybox.message("#story.mes.hinan.1.18", "???")
keybox.message("#story.mes.hinan.1.19", "KeyBoxer")

keybox.run(function()

obj("KeyBoxer"):TranslateX(-300, 1)
obj("Nann").active = true
obj("Nann"):TranslateX(500, 0, 1)
--obj("Nann"):Fade(0.5, true)
end)

keybox.wait(1)

--[[keybox.run(function()

obj("KeyBoxer").ox = -300
obj("KeyBoxer"):Fade(0.5)
obj("Nann"):Fade(0.5)
obj("Nann").ox = 300
end)

keybox.wait(0.5)]]

--[[local maxtime = 1
local time = maxtime

keybox.runrepeat(maxtime, function(deltatime)
print("b")
time = time - deltatime
obj("Nann").ox = (time / maxtime) * 700 + 300
obj("KeyBoxer").ox = (time / maxtime) * 300 - 300
end)
keybox.wait(maxtime)
]]
keybox.addCharacterSync("KeyBoxer", "KeyBoxer")
keybox.addCharacterSync("Nann", "#story.character.nann")
keybox.setCharacterSync(true)

keybox.setFace("Nann", 1, 1)
keybox.message("#story.mes.hinan.1.20", "???")
keybox.message("#story.mes.hinan.1.21", "KeyBoxer")
keybox.setFace("Nann", 0, 2)
keybox.message("#story.mes.hinan.1.22", "???")
keybox.setFace("Nann", 0, 3)
keybox.message("#story.mes.hinan.1.23", "KeyBoxer")
keybox.message("#story.mes.hinan.1.24", "KeyBoxer")
keybox.setFace("Nann", 0, 1)
keybox.message("#story.mes.hinan.1.25", "???")
keybox.setFace("Nann", 0, 0)
keybox.message("#story.mes.hinan.1.26", "KeyBoxer")
keybox.setFace("Nann", 0, 1)
keybox.message("#story.mes.hinan.1.27", "#story.character.nann")
keybox.setFace("Nann", 0, 0)
keybox.message("#story.mes.hinan.1.28", "KeyBoxer")
keybox.setFace("Nann", 3, 1)
keybox.message("#story.mes.hinan.1.29", "#story.character.nann")
keybox.setFace("Nann", 0, 2)
keybox.message("#story.mes.hinan.1.30", "#story.character.nann")
keybox.setFace("Nann", 0, 0)
keybox.message("#story.mes.hinan.1.31", "KeyBoxer")
keybox.setFace("Nann", 0, 1)
keybox.message("#story.mes.hinan.1.32", "#story.character.nann")
keybox.setFace("Nann", 0, 0)
keybox.message("#story.mes.hinan.1.33", "KeyBoxer")
keybox.setFace("Nann", 0, 2)
keybox.message("#story.mes.hinan.1.34", "#story.character.nann")
keybox.setFace("Nann", 0, 3)
keybox.message("#story.mes.hinan.1.35", "KeyBoxer")
keybox.message("#story.mes.hinan.1.36", "KeyBoxer")
keybox.setFace("Nann", 5, 2)
keybox.message("#story.mes.hinan.1.37", "#story.character.nann")

keybox.endstory(1)